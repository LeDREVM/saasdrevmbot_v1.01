# Copy-trading + comptes normaux (façon Invo) pour saasdrevmbot

## Contenu

- `copy_trading.py` — moteur copy-trading (traders, followers, réplication, leaderboard).
- `routes_copytrading_flask.py` — endpoints Flask du copy-trading.
- `routes_copytrading_fastapi.py` — endpoints FastAPI équivalents.
- `account_manager.py` — **NOUVEAU** : comptes normaux (trading manuel + copy-trading + bascule auto), partage la même base SQLite que `copy_trading.py`.
- `routes_accounts_flask.py` — **NOUVEAU** : endpoints Flask pour les comptes.

Garde uniquement les fichiers de routes Flask (ta stack), supprime `routes_copytrading_fastapi.py` si inutile.

## Installation

```python
from routes_copytrading_flask import copytrading_bp
from routes_accounts_flask import accounts_bp

app.register_blueprint(copytrading_bp)
app.register_blueprint(accounts_bp)
```

`account_manager.py` pointe sur `data/copy_trading.db`, la même base que le moteur de copy-trading —
aucune config supplémentaire, les tables se créent automatiquement.

## Le principe "compte normal" que tu as demandé

Un même `account_id` peut cumuler trois choses en même temps, sans conflit :

1. **Trading manuel** — `POST /api/accounts/<id>/manual-trades/open` : tu ouvres un trade toi-même,
   totalement indépendant du reste.
2. **Copy-trading** — via `follow_trader()` (module copy_trading) : ce compte reçoit automatiquement
   les ordres copiés d'un trader que tu suis (ex: un signal FiboAlgoBot externe, ou un autre utilisateur).
3. **Mode auto** — `POST /api/accounts/<id>/auto-mode {"enabled": true}` : un simple interrupteur
   que ton bridge MT5/FiboAlgoBot doit vérifier (`GET /api/accounts/<id>`, champ `auto_mode`)
   avant d'exécuter des trades automatiquement sur ce compte. Ça ne déclenche rien tout seul —
   c'est à FiboAlgoBot de respecter ce flag côté exécution.

Le dashboard combiné (`GET /api/accounts/<id>/dashboard`) fusionne les deux flux (manuel + copié)
en une seule vue : P&L global, win rate, positions ouvertes des deux types côte à côte —
exactement le tableau de bord personnel d'Invo, mais qui n'ignore pas tes trades manuels.

## Comment ça s'articule avec ton archi FiboAlgoBot / Kyrrahannon

```
                     ┌─────────────────────────────┐
                     │   Compte MT5 normal (toi)     │
                     └───────────────┬─────────────┘
                                     │
        ┌────────────────────────────┼────────────────────────────┐
        │                            │                            │
  Trade manuel                Copie automatique          Mode auto (flag)
  (toi, à la main)          (tu suis un trader)         vérifié par le bridge
        │                            │                     avant d'exécuter
        ▼                            ▼                     FiboAlgoBot dessus
  log_manual_trade()      mirrored_orders générés
  close_manual_trade()    par open_trade() du trader
        │                            │
        └────────────┬───────────────┘
                      ▼
        get_account_dashboard()
        (P&L + win rate fusionnés)
```

## Test effectué

Scénario : un compte qui suit un trader (ratio 0.5) reçoit une copie automatique sur XAUUSD,
pendant que le même compte ouvre en parallèle un trade manuel sur EURUSD. Les deux positions
apparaissent ensemble dans le dashboard avant clôture, puis fusionnent proprement après
clôture (win rate 100%, P&L combiné +1.10%). Le toggle auto a aussi été testé (off → on).

## Ce qu'il reste à brancher côté toi

- **Authentification** : toujours aucune sécurité sur ces endpoints — à protéger avant prod.
- **Compliance The5%ers** : vérifie les règles anti-abus si des comptes prop firm participent au copy-trading.
- **Bridge MT5** : c'est à ton bridge Express.js de lire le flag `auto_mode` avant de laisser
  FiboAlgoBot passer des ordres automatiques sur un compte — ce module fournit juste l'état,
  pas l'exécution.
- **Monétisation** (fonction Invo "earn from followers") : toujours pas implémentée, dis-moi si tu la veux.

