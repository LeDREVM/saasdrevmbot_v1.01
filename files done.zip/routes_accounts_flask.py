"""
routes_accounts_flask.py
---------------------------
Blueprint Flask pour les "comptes normaux" (manuel + copy-trading + auto).

Intégration :
    from routes_accounts_flask import accounts_bp
    app.register_blueprint(accounts_bp)

Endpoints :
    POST /api/accounts                          -> créer/mettre à jour un compte
    GET  /api/accounts/<id>                      -> infos du compte
    POST /api/accounts/<id>/auto-mode             -> activer/désactiver l'automatisation
    POST /api/accounts/<id>/manual-trades/open    -> ouvrir un trade manuel
    POST /api/accounts/manual-trades/<id>/close   -> clôturer un trade manuel
    GET  /api/accounts/<id>/manual-trades         -> historique des trades manuels
    GET  /api/accounts/<id>/dashboard             -> vue combinée manuel + copié (façon Invo)
"""

from flask import Blueprint, request, jsonify
from account_manager import AccountManager

accounts_bp = Blueprint("accounts", __name__, url_prefix="/api/accounts")

# Même base que le copy-trading -> les deux modules partagent les mêmes tables trades/mirrored_orders
manager = AccountManager(db_path="data/copy_trading.db")


@accounts_bp.route("", methods=["POST"])
def create_account():
    data = request.get_json(force=True)
    name = data.get("name")
    if not name:
        return jsonify({"error": "Le champ 'name' est requis"}), 400
    account_id = manager.register_account(
        name=name,
        account_id=data.get("account_id"),  # optionnel : réutilise un ID existant (ex: MT5 login)
        mt5_account_id=data.get("mt5_account_id", ""),
    )
    return jsonify({"account_id": account_id}), 201


@accounts_bp.route("/<account_id>", methods=["GET"])
def get_account(account_id):
    account = manager.get_account(account_id)
    if not account:
        return jsonify({"error": "Compte introuvable"}), 404
    return jsonify(account)


@accounts_bp.route("/<account_id>/auto-mode", methods=["POST"])
def toggle_auto_mode(account_id):
    data = request.get_json(force=True)
    enabled = bool(data.get("enabled", False))
    manager.set_auto_mode(account_id, enabled)
    return jsonify({"account_id": account_id, "auto_mode": enabled})


@accounts_bp.route("/<account_id>/manual-trades/open", methods=["POST"])
def open_manual_trade(account_id):
    data = request.get_json(force=True)
    try:
        trade_id = manager.log_manual_trade(
            account_id=account_id,
            symbol=data["symbol"],
            direction=data["direction"],
            lot_size=float(data["lot_size"]),
            open_price=float(data["open_price"]),
            sl=data.get("sl"),
            tp=data.get("tp"),
        )
    except KeyError as e:
        return jsonify({"error": f"Champ manquant : {e}"}), 400
    return jsonify({"trade_id": trade_id}), 201


@accounts_bp.route("/manual-trades/<trade_id>/close", methods=["POST"])
def close_manual_trade(trade_id):
    data = request.get_json(force=True)
    try:
        result = manager.close_manual_trade(trade_id, float(data["close_price"]))
    except ValueError as e:
        return jsonify({"error": str(e)}), 404
    return jsonify(result)


@accounts_bp.route("/<account_id>/manual-trades", methods=["GET"])
def list_manual_trades(account_id):
    status = request.args.get("status")
    return jsonify(manager.get_manual_trades(account_id, status=status))


@accounts_bp.route("/<account_id>/dashboard", methods=["GET"])
def dashboard(account_id):
    return jsonify(manager.get_account_dashboard(account_id))
