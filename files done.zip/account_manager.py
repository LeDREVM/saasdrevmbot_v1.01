"""
account_manager.py
---------------------
Extension de copy_trading.py : gestion des "comptes normaux".

Un compte normal peut, en même temps :
    1. Trader manuellement (log_manual_trade / close_manual_trade)
    2. Suivre un ou plusieurs traders via CopyTradingEngine.follow_trader()
       -> il reçoit alors des mirrored_orders automatiquement
    3. Basculer en mode automatisé (set_auto_mode) pour autoriser
       FiboAlgoBot à ouvrir des trades directement dessus
       (le compte devient alors aussi "trader" via CopyTradingEngine.open_trade())

get_account_dashboard() fusionne les deux flux (manuel + copié) en une
seule vue façon Invo : P&L global, win rate, positions ouvertes.

Utilise la même base SQLite que copy_trading.py (mêmes tables trades/
mirrored_orders/followers), ajoute juste "accounts" et "manual_trades".
"""

from __future__ import annotations

import sqlite3
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional, Union


class AccountManager:
    def __init__(self, db_path: Union[str, Path] = "copy_trading.db"):
        self.db_path = str(db_path)
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path)

    def _init_db(self) -> None:
        with self._conn() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS accounts (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    mt5_account_id TEXT,
                    auto_mode INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS manual_trades (
                    id TEXT PRIMARY KEY,
                    account_id TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    lot_size REAL NOT NULL,
                    open_price REAL NOT NULL,
                    sl REAL,
                    tp REAL,
                    status TEXT NOT NULL,
                    opened_at TEXT NOT NULL,
                    close_price REAL,
                    closed_at TEXT,
                    pnl_pct REAL
                )
                """
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_manual_account ON manual_trades(account_id)")

    # ------------------------------------------------------------------ #
    # Gestion du compte
    # ------------------------------------------------------------------ #
    def register_account(self, name: str, account_id: Optional[str] = None, mt5_account_id: str = "") -> str:
        """
        account_id : si fourni, réutilise cet identifiant (pratique pour aligner
        avec le follower_account_id / trader_id déjà utilisés dans CopyTradingEngine).
        Sinon un UUID est généré.
        """
        account_id = account_id or str(uuid.uuid4())
        with self._conn() as conn:
            conn.execute(
                """
                INSERT INTO accounts (id, name, mt5_account_id, auto_mode, created_at)
                VALUES (?, ?, ?, 0, ?)
                ON CONFLICT(id) DO UPDATE SET name=excluded.name, mt5_account_id=excluded.mt5_account_id
                """,
                (account_id, name, mt5_account_id, datetime.utcnow().isoformat()),
            )
        return account_id

    def set_auto_mode(self, account_id: str, enabled: bool) -> None:
        """Active/désactive l'automatisation (FiboAlgoBot autorisé à trader sur ce compte)."""
        with self._conn() as conn:
            conn.execute("UPDATE accounts SET auto_mode=? WHERE id=?", (1 if enabled else 0, account_id))

    def is_auto_mode(self, account_id: str) -> bool:
        with self._conn() as conn:
            row = conn.execute("SELECT auto_mode FROM accounts WHERE id=?", (account_id,)).fetchone()
        return bool(row[0]) if row else False

    def get_account(self, account_id: str) -> Optional[dict]:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT id, name, mt5_account_id, auto_mode, created_at FROM accounts WHERE id=?",
                (account_id,),
            ).fetchone()
        if not row:
            return None
        return {"id": row[0], "name": row[1], "mt5_account_id": row[2], "auto_mode": bool(row[3]), "created_at": row[4]}

    # ------------------------------------------------------------------ #
    # Trading manuel (indépendant du copy-trading, sur le même compte)
    # ------------------------------------------------------------------ #
    def log_manual_trade(
        self,
        account_id: str,
        symbol: str,
        direction: str,
        lot_size: float,
        open_price: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
    ) -> str:
        trade_id = str(uuid.uuid4())
        with self._conn() as conn:
            conn.execute(
                """
                INSERT INTO manual_trades (id, account_id, symbol, direction, lot_size, open_price, sl, tp, status, opened_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open', ?)
                """,
                (trade_id, account_id, symbol, direction, lot_size, open_price, sl, tp, datetime.utcnow().isoformat()),
            )
        return trade_id

    def close_manual_trade(self, trade_id: str, close_price: float) -> dict:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT direction, open_price FROM manual_trades WHERE id=?", (trade_id,)
            ).fetchone()
            if row is None:
                raise ValueError(f"Trade manuel introuvable : {trade_id}")
            direction, open_price = row
            pnl_pct = self._pnl_pct(direction, open_price, close_price)
            conn.execute(
                "UPDATE manual_trades SET status='closed', close_price=?, closed_at=?, pnl_pct=? WHERE id=?",
                (close_price, datetime.utcnow().isoformat(), pnl_pct, trade_id),
            )
        return {"trade_id": trade_id, "close_price": close_price, "pnl_pct": pnl_pct}

    @staticmethod
    def _pnl_pct(direction: str, open_price: float, close_price: float) -> float:
        if open_price == 0:
            return 0.0
        raw = (close_price - open_price) / open_price
        if direction.lower() == "sell":
            raw = -raw
        return round(raw * 100, 4)

    def get_manual_trades(self, account_id: str, status: Optional[str] = None) -> list[dict]:
        query = "SELECT id, symbol, direction, lot_size, open_price, sl, tp, status, opened_at, close_price, closed_at, pnl_pct FROM manual_trades WHERE account_id=?"
        params: list = [account_id]
        if status:
            query += " AND status=?"
            params.append(status)
        query += " ORDER BY opened_at DESC"
        with self._conn() as conn:
            rows = conn.execute(query, params).fetchall()
        cols = ["id", "symbol", "direction", "lot_size", "open_price", "sl", "tp", "status", "opened_at", "close_price", "closed_at", "pnl_pct"]
        return [dict(zip(cols, r)) for r in rows]

    # ------------------------------------------------------------------ #
    # Tableau de bord combiné (manuel + copié) — façon Invo
    # ------------------------------------------------------------------ #
    def get_account_dashboard(self, account_id: str) -> dict:
        with self._conn() as conn:
            # --- Trades manuels clôturés ---
            manual_closed = conn.execute(
                "SELECT pnl_pct FROM manual_trades WHERE account_id=? AND status='closed'", (account_id,)
            ).fetchall()
            manual_open = conn.execute(
                "SELECT id, symbol, direction, lot_size, open_price, opened_at FROM manual_trades WHERE account_id=? AND status='open'",
                (account_id,),
            ).fetchall()

            # --- Trades copiés : on rejoint mirrored_orders (ce compte comme follower)
            #     avec trades (le trader suivi) pour récupérer le pnl_pct du trade source.
            copied_closed = conn.execute(
                """
                SELECT t.pnl_pct, t.symbol, mo.lot_size
                FROM mirrored_orders mo
                JOIN trades t ON t.id = mo.trade_id
                WHERE mo.follower_account_id=? AND t.status='closed'
                """,
                (account_id,),
            ).fetchall()
            copied_open = conn.execute(
                """
                SELECT mo.id, mo.symbol, mo.direction, mo.lot_size, mo.status, mo.created_at
                FROM mirrored_orders mo
                WHERE mo.follower_account_id=? AND mo.status IN ('pending', 'sent')
                """,
                (account_id,),
            ).fetchall()

        manual_pnl_values = [r[0] for r in manual_closed if r[0] is not None]
        copied_pnl_values = [r[0] for r in copied_closed if r[0] is not None]
        all_pnl_values = manual_pnl_values + copied_pnl_values

        nb_trades = len(all_pnl_values)
        nb_wins = sum(1 for p in all_pnl_values if p > 0)
        win_rate = round((nb_wins / nb_trades) * 100, 1) if nb_trades else 0.0
        total_pnl_pct = round(sum(all_pnl_values), 2)

        return {
            "account_id": account_id,
            "summary": {
                "nb_trades": nb_trades,
                "win_rate": win_rate,
                "total_pnl_pct": total_pnl_pct,
                "nb_manual_trades": len(manual_pnl_values),
                "nb_copied_trades": len(copied_pnl_values),
            },
            "open_positions": {
                "manual": [
                    {"id": r[0], "symbol": r[1], "direction": r[2], "lot_size": r[3], "open_price": r[4], "opened_at": r[5]}
                    for r in manual_open
                ],
                "copied": [
                    {"order_id": r[0], "symbol": r[1], "direction": r[2], "lot_size": r[3], "status": r[4], "created_at": r[5]}
                    for r in copied_open
                ],
            },
        }
