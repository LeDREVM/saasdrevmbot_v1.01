#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
 ALGO DE TRADING AUTOMATIQUE — Moteur d'analyse pour workflow n8n
================================================================================
 Logique : SMC (structure BOS/CHoCH) + Fibonacci (golden zone) + RSI/divergence
           + filtre de session (NY/London) + scoring de confluence (0-100)
           + sizing & garde-fous FTMO (1% risque, drawdown daily/total).

 Usage :
   - Service web (recommandé pour n8n) :  uvicorn trading_algo_n8n:app --port 8000
     -> n8n appelle POST /analyze  (noeud HTTP Request)
   - Mode CLI (alternative noeud Execute Command) :
     python trading_algo_n8n.py XAUUSD 1h

 Dépendances :  pip install fastapi uvicorn pandas numpy requests pydantic
================================================================================
"""

import os
import sys
import json
import math
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Optional

import numpy as np
import pandas as pd
import requests

# ------------------------------------------------------------------------------
# 1) CONFIGURATION (via variables d'environnement, valeurs par défaut sûres)
# ------------------------------------------------------------------------------

CONFIG = {
    "TWELVE_DATA_KEY": os.getenv("TWELVE_DATA_KEY", ""),
    "DISCORD_WEBHOOK": os.getenv("DISCORD_WEBHOOK", ""),

    # Seuil de confluence pour déclencher un signal (sur 100)
    "CONFLUENCE_THRESHOLD": int(os.getenv("CONFLUENCE_THRESHOLD", "65")),

    # Compte / FTMO
    "ACCOUNT_BALANCE": float(os.getenv("ACCOUNT_BALANCE", "100000")),
    "ACCOUNT_EQUITY": float(os.getenv("ACCOUNT_EQUITY", "100000")),
    "RISK_PCT": float(os.getenv("RISK_PCT", "1.0")),          # % risque / trade (FTMO hard)
    "FTMO_DAILY_DD_PCT": float(os.getenv("FTMO_DAILY_DD_PCT", "5.0")),
    "FTMO_TOTAL_DD_PCT": float(os.getenv("FTMO_TOTAL_DD_PCT", "10.0")),
    "FTMO_INITIAL_BALANCE": float(os.getenv("FTMO_INITIAL_BALANCE", "100000")),
    "DAY_START_EQUITY": float(os.getenv("DAY_START_EQUITY", "100000")),
}

# Spécifications des instruments : valeur d'1 unité de prix par lot.
# XAUUSD : 1 lot = 100 oz -> un mouvement de 1.00$ = 100$ / lot.
INSTRUMENTS = {
    "XAUUSD": {"value_per_price_unit": 100.0, "min_sl": 1.5,  "atr_sl_mult": 1.5, "atr_tp_mult": 3.0},
    "BTCUSD": {"value_per_price_unit": 1.0,   "min_sl": 50.0, "atr_sl_mult": 1.5, "atr_tp_mult": 3.0},
    "EURUSD": {"value_per_price_unit": 100000.0, "min_sl": 0.0008, "atr_sl_mult": 1.5, "atr_tp_mult": 3.0},
    "USDJPY": {"value_per_price_unit": 1000.0, "min_sl": 0.08, "atr_sl_mult": 1.5, "atr_tp_mult": 3.0},
}
DEFAULT_INSTRUMENT = {"value_per_price_unit": 1.0, "min_sl": 0.0, "atr_sl_mult": 1.5, "atr_tp_mult": 3.0}


# ------------------------------------------------------------------------------
# 2) RÉCUPÉRATION DES DONNÉES (Twelve Data)  — n8n peut aussi fournir les bougies
# ------------------------------------------------------------------------------

def fetch_candles(symbol: str, interval: str = "1h", outputsize: int = 250) -> pd.DataFrame:
    """Récupère les bougies OHLC via Twelve Data et renvoie un DataFrame trié (ancien -> récent)."""
    td_symbol = symbol
    mapping = {"XAUUSD": "XAU/USD", "BTCUSD": "BTC/USD", "EURUSD": "EUR/USD", "USDJPY": "USD/JPY"}
    td_symbol = mapping.get(symbol.upper(), symbol)

    url = "https://api.twelvedata.com/time_series"
    params = {
        "symbol": td_symbol,
        "interval": interval,
        "outputsize": outputsize,
        "apikey": CONFIG["TWELVE_DATA_KEY"],
        "format": "JSON",
    }
    r = requests.get(url, params=params, timeout=20)
    data = r.json()
    if "values" not in data:
        raise RuntimeError(f"Twelve Data error: {data.get('message', data)}")

    df = pd.DataFrame(data["values"])
    for c in ["open", "high", "low", "close"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["datetime"] = pd.to_datetime(df["datetime"])
    df = df.sort_values("datetime").reset_index(drop=True)
    return df[["datetime", "open", "high", "low", "close"]].dropna()


def df_from_candles(candles: List[Dict]) -> pd.DataFrame:
    """Construit un DataFrame depuis une liste de bougies fournies par n8n."""
    df = pd.DataFrame(candles)
    for c in ["open", "high", "low", "close"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    if "datetime" in df.columns:
        df["datetime"] = pd.to_datetime(df["datetime"])
        df = df.sort_values("datetime").reset_index(drop=True)
    return df.dropna().reset_index(drop=True)


# ------------------------------------------------------------------------------
# 3) INDICATEURS
# ------------------------------------------------------------------------------

def ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False).mean()


def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    return (100 - (100 / (1 + rs))).fillna(50)


def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    h, l, c = df["high"], df["low"], df["close"]
    prev_c = c.shift(1)
    tr = pd.concat([h - l, (h - prev_c).abs(), (l - prev_c).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / period, adjust=False).mean()


def find_swings(df: pd.DataFrame, left: int = 2, right: int = 2):
    """Détecte les swings highs/lows (fractals simples). Renvoie deux listes d'index."""
    h, l = df["high"].values, df["low"].values
    n = len(df)
    swing_highs, swing_lows = [], []
    for i in range(left, n - right):
        win_h = h[i - left:i + right + 1]
        win_l = l[i - left:i + right + 1]
        if h[i] == win_h.max() and (win_h == h[i]).sum() == 1:
            swing_highs.append(i)
        if l[i] == win_l.min() and (win_l == l[i]).sum() == 1:
            swing_lows.append(i)
    return swing_highs, swing_lows


# ------------------------------------------------------------------------------
# 4) STRUCTURE DE MARCHÉ (SMC simplifié : tendance + BOS / CHoCH)
# ------------------------------------------------------------------------------

def market_structure(df: pd.DataFrame):
    """Détermine la tendance et l'événement structurel récent (BOS / CHoCH)."""
    sh_idx, sl_idx = find_swings(df)
    close = df["close"].iloc[-1]

    last_highs = [df["high"].iloc[i] for i in sh_idx[-3:]]
    last_lows = [df["low"].iloc[i] for i in sl_idx[-3:]]

    trend = "RANGE"
    if len(last_highs) >= 2 and len(last_lows) >= 2:
        hh = last_highs[-1] > last_highs[-2]
        hl = last_lows[-1] > last_lows[-2]
        lh = last_highs[-1] < last_highs[-2]
        ll = last_lows[-1] < last_lows[-2]
        if hh and hl:
            trend = "UP"
        elif lh and ll:
            trend = "DOWN"

    last_swing_high = last_highs[-1] if last_highs else close
    last_swing_low = last_lows[-1] if last_lows else close

    event = "NONE"
    if trend == "UP" and close > last_swing_high:
        event = "BOS_UP"          # continuation haussière
    elif trend == "DOWN" and close < last_swing_low:
        event = "BOS_DOWN"        # continuation baissière
    elif trend == "DOWN" and close > last_swing_high:
        event = "CHOCH_UP"        # changement de caractère -> potentiel retournement haussier
    elif trend == "UP" and close < last_swing_low:
        event = "CHOCH_DOWN"      # changement de caractère -> potentiel retournement baissier

    return {
        "trend": trend,
        "event": event,
        "last_swing_high": round(float(last_swing_high), 5),
        "last_swing_low": round(float(last_swing_low), 5),
    }


# ------------------------------------------------------------------------------
# 5) FIBONACCI (golden zone / discount-premium)
# ------------------------------------------------------------------------------

def fibonacci_zone(swing_low: float, swing_high: float, price: float, bias: str):
    """Calcule les niveaux Fibo et indique si le prix est dans la golden zone (0.5–0.786)."""
    diff = swing_high - swing_low
    if diff <= 0:
        return {"in_golden_zone": False, "levels": {}}

    ratios = [0, 0.236, 0.382, 0.5, 0.618, 0.705, 0.786, 0.886, 0.95, 1]
    if bias == "UP":   # retracement depuis le haut (entrée achat en discount)
        levels = {str(r): round(swing_high - diff * r, 5) for r in ratios}
        lo, hi = levels["0.786"], levels["0.5"]
        in_zone = lo <= price <= hi
    else:              # retracement depuis le bas (entrée vente en premium)
        levels = {str(r): round(swing_low + diff * r, 5) for r in ratios}
        lo, hi = levels["0.5"], levels["0.786"]
        in_zone = lo <= price <= hi

    return {"in_golden_zone": bool(in_zone), "levels": levels,
            "golden_low": round(lo, 5), "golden_high": round(hi, 5)}


# ------------------------------------------------------------------------------
# 6) DIVERGENCE RSI (version simplifiée sur swings récents)
# ------------------------------------------------------------------------------

def rsi_divergence(df: pd.DataFrame, rsi_series: pd.Series) -> str:
    sh_idx, sl_idx = find_swings(df)
    div = "NONE"
    if len(sl_idx) >= 2:
        a, b = sl_idx[-2], sl_idx[-1]
        if df["low"].iloc[b] < df["low"].iloc[a] and rsi_series.iloc[b] > rsi_series.iloc[a]:
            div = "BULLISH"   # prix LL, RSI HL
    if len(sh_idx) >= 2:
        a, b = sh_idx[-2], sh_idx[-1]
        if df["high"].iloc[b] > df["high"].iloc[a] and rsi_series.iloc[b] < rsi_series.iloc[a]:
            div = "BEARISH"   # prix HH, RSI LH
    return div


# ------------------------------------------------------------------------------
# 7) FILTRE DE SESSION (NY / London en UTC)
# ------------------------------------------------------------------------------

def active_session(now_utc: Optional[datetime] = None) -> Dict:
    now = now_utc or datetime.now(timezone.utc)
    h = now.hour
    london = 7 <= h < 16     # ~08:00-16:00 UK
    newyork = 12 <= h < 21   # ~08:00-16:00 ET
    name = "NY+LONDON" if (london and newyork) else "LONDON" if london else "NY" if newyork else "HORS-SESSION"
    return {"active": bool(london or newyork), "session": name}


# ------------------------------------------------------------------------------
# 8) MOTEUR DE CONFLUENCE  (cœur de la décision)
# ------------------------------------------------------------------------------

def confluence_engine(df: pd.DataFrame, symbol: str) -> Dict:
    close = float(df["close"].iloc[-1])
    e9, e21, e50, e200 = ema(df["close"], 9), ema(df["close"], 21), ema(df["close"], 50), ema(df["close"], 200)
    rsi14 = rsi(df["close"], 14)
    atr14 = float(atr(df, 14).iloc[-1])
    rsi_now = float(rsi14.iloc[-1])

    struct = market_structure(df)
    div = rsi_divergence(df, rsi14)
    sess = active_session()

    # Biais EMA
    ema_bias = "UP" if (e9.iloc[-1] > e21.iloc[-1] > e50.iloc[-1]) else \
               "DOWN" if (e9.iloc[-1] < e21.iloc[-1] < e50.iloc[-1]) else "RANGE"
    trend_d1 = "UP" if close > e200.iloc[-1] else "DOWN"

    # Biais directionnel proposé (structure prioritaire, sinon EMA)
    bias = struct["trend"] if struct["trend"] != "RANGE" else ema_bias

    fib = fibonacci_zone(struct["last_swing_low"], struct["last_swing_high"], close, bias)

    # ----- SCORING (0-100) -----
    score, reasons = 0, []

    # Alignement tendance (structure + EMA + D1) — 30 pts
    if bias != "RANGE":
        if ema_bias == bias:
            score += 15; reasons.append(f"EMA alignées {bias} (+15)")
        if trend_d1 == bias:
            score += 15; reasons.append(f"Tendance EMA200 {bias} (+15)")

    # Zone Fibonacci golden — 20 pts
    if fib.get("in_golden_zone"):
        score += 20; reasons.append("Prix en golden zone 0.5–0.786 (+20)")

    # Structure SMC (BOS continuation / CHoCH aligné) — 20 pts
    if struct["event"] in ("BOS_UP", "CHOCH_UP") and bias == "UP":
        score += 20; reasons.append(f"{struct['event']} aligné (+20)")
    elif struct["event"] in ("BOS_DOWN", "CHOCH_DOWN") and bias == "DOWN":
        score += 20; reasons.append(f"{struct['event']} aligné (+20)")

    # RSI / divergence — 20 pts
    if bias == "UP" and (rsi_now < 45 or div == "BULLISH"):
        score += 10; reasons.append("RSI favorable achat (+10)")
        if div == "BULLISH":
            score += 10; reasons.append("Divergence RSI haussière (+10)")
    elif bias == "DOWN" and (rsi_now > 55 or div == "BEARISH"):
        score += 10; reasons.append("RSI favorable vente (+10)")
        if div == "BEARISH":
            score += 10; reasons.append("Divergence RSI baissière (+10)")

    # Session — 10 pts
    if sess["active"]:
        score += 10; reasons.append(f"Session {sess['session']} active (+10)")

    score = min(score, 100)

    # ----- DÉCISION + niveaux -----
    inst = INSTRUMENTS.get(symbol.upper(), DEFAULT_INSTRUMENT)
    sl_dist = max(atr14 * inst["atr_sl_mult"], inst["min_sl"])

    action, entry, sl, tp1, tp2 = "WAIT", close, None, None, None
    if score >= CONFIG["CONFLUENCE_THRESHOLD"] and sess["active"] and bias != "RANGE":
        if bias == "UP":
            action = "BUY"
            sl = round(close - sl_dist, 5)
            tp1 = round(close + sl_dist * 1.5, 5)
            tp2 = round(close + atr14 * inst["atr_tp_mult"], 5)
        else:
            action = "SELL"
            sl = round(close + sl_dist, 5)
            tp1 = round(close - sl_dist * 1.5, 5)
            tp2 = round(close - atr14 * inst["atr_tp_mult"], 5)

    rr = round(abs(tp1 - entry) / abs(entry - sl), 2) if (sl and tp1) else None

    return {
        "symbol": symbol.upper(),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "price": round(close, 5),
        "bias": bias,
        "action": action,
        "confluence_score": score,
        "threshold": CONFIG["CONFLUENCE_THRESHOLD"],
        "entry": round(entry, 5),
        "sl": sl,
        "tp1": tp1,
        "tp2": tp2,
        "risk_reward": rr,
        "atr": round(atr14, 5),
        "rsi": round(rsi_now, 2),
        "structure": struct,
        "fibonacci": {"in_golden_zone": fib.get("in_golden_zone"),
                      "golden_low": fib.get("golden_low"),
                      "golden_high": fib.get("golden_high")},
        "session": sess,
        "reasons": reasons,
    }


# ------------------------------------------------------------------------------
# 9) RISK MANAGER FTMO  (sizing + garde-fous drawdown)
# ------------------------------------------------------------------------------

def risk_check_and_size(signal: Dict) -> Dict:
    eq = CONFIG["ACCOUNT_EQUITY"]
    init = CONFIG["FTMO_INITIAL_BALANCE"]
    day_start = CONFIG["DAY_START_EQUITY"]

    daily_dd = (day_start - eq) / day_start * 100
    total_dd = (init - eq) / init * 100

    blocked, block_reason = False, None
    if daily_dd >= CONFIG["FTMO_DAILY_DD_PCT"]:
        blocked, block_reason = True, f"KILL SWITCH: drawdown daily {daily_dd:.2f}% >= {CONFIG['FTMO_DAILY_DD_PCT']}%"
    elif total_dd >= CONFIG["FTMO_TOTAL_DD_PCT"]:
        blocked, block_reason = True, f"KILL SWITCH: drawdown total {total_dd:.2f}% >= {CONFIG['FTMO_TOTAL_DD_PCT']}%"

    lots = 0.0
    if signal["action"] in ("BUY", "SELL") and signal["sl"] and not blocked:
        inst = INSTRUMENTS.get(signal["symbol"], DEFAULT_INSTRUMENT)
        risk_amount = eq * CONFIG["RISK_PCT"] / 100
        price_dist = abs(signal["entry"] - signal["sl"])
        if price_dist > 0:
            lots = round(risk_amount / (price_dist * inst["value_per_price_unit"]), 2)

    if blocked:
        signal["action"] = "BLOCKED"

    signal["risk"] = {
        "lots": lots,
        "risk_pct": CONFIG["RISK_PCT"],
        "risk_amount": round(eq * CONFIG["RISK_PCT"] / 100, 2),
        "daily_dd_pct": round(daily_dd, 2),
        "total_dd_pct": round(total_dd, 2),
        "blocked": blocked,
        "block_reason": block_reason,
    }
    signal["valid"] = (signal["action"] in ("BUY", "SELL")) and lots > 0
    return signal


# ------------------------------------------------------------------------------
# 10) NOTIFICATION DISCORD (optionnelle — n8n peut aussi s'en charger)
# ------------------------------------------------------------------------------

def notify_discord(signal: Dict):
    if not CONFIG["DISCORD_WEBHOOK"]:
        return False
    color = 0x2ecc71 if signal["action"] == "BUY" else 0xe74c3c if signal["action"] == "SELL" else 0x95a5a6
    embed = {
        "title": f"🎯 {signal['symbol']} — {signal['action']} ({signal['confluence_score']}/100)",
        "color": color,
        "fields": [
            {"name": "Prix", "value": str(signal["price"]), "inline": True},
            {"name": "Biais", "value": signal["bias"], "inline": True},
            {"name": "R/R", "value": str(signal.get("risk_reward")), "inline": True},
            {"name": "Entry", "value": str(signal["entry"]), "inline": True},
            {"name": "SL", "value": str(signal["sl"]), "inline": True},
            {"name": "TP1 / TP2", "value": f"{signal['tp1']} / {signal['tp2']}", "inline": True},
            {"name": "Lots", "value": str(signal["risk"]["lots"]), "inline": True},
            {"name": "Session", "value": signal["session"]["session"], "inline": True},
            {"name": "Confluence", "value": "\n".join(f"• {r}" for r in signal["reasons"]) or "—", "inline": False},
        ],
        "footer": {"text": "Algo SMC+Fibo+RSI | n8n"},
        "timestamp": signal["timestamp"],
    }
    try:
        requests.post(CONFIG["DISCORD_WEBHOOK"], json={"username": "🤖 Algo Trading", "embeds": [embed]}, timeout=10)
        return True
    except Exception:
        return False


# ------------------------------------------------------------------------------
# 11) ORCHESTRATION
# ------------------------------------------------------------------------------

def run_analysis(symbol: str, interval: str = "1h",
                 candles: Optional[List[Dict]] = None, send_discord: bool = False) -> Dict:
    df = df_from_candles(candles) if candles else fetch_candles(symbol, interval)
    if len(df) < 210:
        return {"symbol": symbol, "action": "WAIT", "valid": False,
                "error": f"Pas assez de bougies ({len(df)}), 210+ requis pour EMA200."}
    signal = confluence_engine(df, symbol)
    signal = risk_check_and_size(signal)
    if send_discord and signal.get("valid"):
        signal["discord_sent"] = notify_discord(signal)
    return signal


# ------------------------------------------------------------------------------
# 12) API FastAPI  (point d'entrée pour n8n)
# ------------------------------------------------------------------------------

try:
    from fastapi import FastAPI
    from pydantic import BaseModel

    app = FastAPI(title="Algo Trading n8n", version="1.0")

    class AnalyzeRequest(BaseModel):
        symbol: str
        interval: str = "1h"
        candles: Optional[List[Dict]] = None     # n8n peut fournir les bougies
        send_discord: bool = False

    @app.get("/health")
    def health():
        return {"status": "ok", "time": datetime.now(timezone.utc).isoformat()}

    @app.post("/analyze")
    def analyze(req: AnalyzeRequest):
        return run_analysis(req.symbol, req.interval, req.candles, req.send_discord)

except ImportError:
    app = None  # FastAPI non installé : le mode CLI reste utilisable


# ------------------------------------------------------------------------------
# 13) MODE CLI
# ------------------------------------------------------------------------------

if __name__ == "__main__":
    if len(sys.argv) >= 2 and sys.argv[1] not in ("serve", "uvicorn"):
        sym = sys.argv[1]
        itv = sys.argv[2] if len(sys.argv) > 2 else "1h"
        out = run_analysis(sym, itv, send_discord=bool(CONFIG["DISCORD_WEBHOOK"]))
        print(json.dumps(out, indent=2, ensure_ascii=False))
    else:
        import uvicorn
        uvicorn.run("trading_algo_n8n:app", host="0.0.0.0", port=8000, reload=False)
