"""
routes_copytrading_flask.py
-----------------------------
Blueprint Flask pour le copy-trading (style Invo) dans saasdrevmbot.

Intégration :
    from routes_copytrading_flask import copytrading_bp
    app.register_blueprint(copytrading_bp)

Endpoints :
    POST /api/copytrading/traders                 -> créer un trader
    POST /api/copytrading/follow                   -> suivre un trader
    POST /api/copytrading/unfollow                  -> arrêter de suivre
    GET  /api/copytrading/traders/<id>/followers    -> liste des followers
    POST /api/copytrading/trades/open               -> ouvrir un trade (déclenche la réplication)
    POST /api/copytrading/trades/<id>/close         -> clôturer un trade
    GET  /api/copytrading/orders/pending/<account>  -> ordres à exécuter (polling bridge MT5)
    POST /api/copytrading/orders/<id>/sent          -> confirmer envoi d'un ordre
    POST /api/copytrading/orders/<id>/failed        -> signaler échec d'un ordre
    GET  /api/copytrading/leaderboard               -> classement des traders
"""

from flask import Blueprint, request, jsonify
from copy_trading import CopyTradingEngine

copytrading_bp = Blueprint("copytrading", __name__, url_prefix="/api/copytrading")

engine = CopyTradingEngine(db_path="data/copy_trading.db")


@copytrading_bp.route("/traders", methods=["POST"])
def create_trader():
    data = request.get_json(force=True)
    name = data.get("name")
    if not name:
        return jsonify({"error": "Le champ 'name' est requis"}), 400
    trader_id = engine.register_trader(name, data.get("mt5_account_id", ""))
    return jsonify({"trader_id": trader_id}), 201


@copytrading_bp.route("/follow", methods=["POST"])
def follow():
    data = request.get_json(force=True)
    try:
        follow_id = engine.follow_trader(
            trader_id=data["trader_id"],
            follower_account_id=data["follower_account_id"],
            risk_mode=data.get("risk_mode", "mirror_ratio"),
            risk_value=float(data.get("risk_value", 1.0)),
        )
    except KeyError as e:
        return jsonify({"error": f"Champ manquant : {e}"}), 400
    return jsonify({"follow_id": follow_id}), 201


@copytrading_bp.route("/unfollow", methods=["POST"])
def unfollow():
    data = request.get_json(force=True)
    engine.unfollow_trader(data["trader_id"], data["follower_account_id"])
    return jsonify({"status": "ok"})


@copytrading_bp.route("/traders/<trader_id>/followers", methods=["GET"])
def followers(trader_id):
    return jsonify(engine.get_followers(trader_id))


@copytrading_bp.route("/trades/open", methods=["POST"])
def open_trade():
    data = request.get_json(force=True)
    try:
        result = engine.open_trade(
            trader_id=data["trader_id"],
            symbol=data["symbol"],
            direction=data["direction"],
            lot_size=float(data["lot_size"]),
            open_price=float(data["open_price"]),
            sl=data.get("sl"),
            tp=data.get("tp"),
            trader_balance=data.get("trader_balance"),
            follower_balances=data.get("follower_balances"),
        )
    except KeyError as e:
        return jsonify({"error": f"Champ manquant : {e}"}), 400
    return jsonify(result), 201


@copytrading_bp.route("/trades/<trade_id>/close", methods=["POST"])
def close_trade(trade_id):
    data = request.get_json(force=True)
    try:
        result = engine.close_trade(trade_id, float(data["close_price"]))
    except ValueError as e:
        return jsonify({"error": str(e)}), 404
    return jsonify(result)


@copytrading_bp.route("/orders/pending/<account_id>", methods=["GET"])
def pending_orders(account_id):
    return jsonify(engine.get_pending_orders_for_account(account_id))


@copytrading_bp.route("/orders/<order_id>/sent", methods=["POST"])
def order_sent(order_id):
    engine.mark_order_sent(order_id)
    return jsonify({"status": "ok"})


@copytrading_bp.route("/orders/<order_id>/failed", methods=["POST"])
def order_failed(order_id):
    engine.mark_order_failed(order_id)
    return jsonify({"status": "ok"})


@copytrading_bp.route("/leaderboard", methods=["GET"])
def leaderboard():
    limit = int(request.args.get("limit", 20))
    return jsonify(engine.get_leaderboard(limit=limit))
