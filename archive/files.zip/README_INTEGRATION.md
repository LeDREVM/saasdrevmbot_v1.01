# Copy-trading (façon Invo) pour saasdrevmbot

## Contenu

- `copy_trading.py` — moteur (traders, followers, réplication, leaderboard). SQLite embarqué, aucune dépendance externe.
- `routes_copytrading_flask.py` — endpoints Flask.
- `routes_copytrading_fastapi.py` — endpoints FastAPI.

Garde uniquement le fichier de routes qui correspond à ta stack (Flask, d'après ta réponse), supprime l'autre.

## Installation

1. Copie `copy_trading.py` + `routes_copytrading_flask.py` dans ton repo (ex: `saasdrevmbot/copytrading/`).
2. Enregistre le blueprint dans ton app principale :
   ```python
   from routes_copytrading_flask import copytrading_bp
   app.register_blueprint(copytrading_bp)
   ```
3. Le fichier `data/copy_trading.db` se crée automatiquement au premier lancement.

## Comment ça s'articule avec ton archi FiboAlgoBot / Kyrrahannon

```
FiboAlgoBot (MT5) détecte un signal GoldXrodgers
        │
        ▼
POST /api/copytrading/trades/open   (trader_id = ton compte MT5-MAIN)
        │
        ▼
Moteur calcule le lot pour chaque follower actif
(mirror_ratio / fixed_lot / pct_balance)
        │
        ▼
Ordres stockés en "pending" dans mirrored_orders
        │
        ▼
Bridge MT5 (Express.js, Kyrrahannon) poll toutes les X secondes :
GET /api/copytrading/orders/pending/<follower_account_id>
        │
        ▼
Bridge exécute l'ordre sur MT5 du follower, puis confirme :
POST /api/copytrading/orders/<order_id>/sent
```

## Les 3 modes de risque disponibles

| Mode           | risk_value représente                          | Exemple                                    |
|----------------|--------------------------------------------------|---------------------------------------------|
| `fixed_lot`    | Un lot fixe, peu importe le trade                 | risk_value=0.1 → toujours 0.1 lot            |
| `mirror_ratio` | Un multiplicateur du lot du trader                | risk_value=0.5 → moitié du lot du trader     |
| `pct_balance`  | Ratio proportionnel au capital du follower        | Follower avec 2x moins de capital → 2x moins de lot |

## Test effectué

Scénario simulé : 1 trader (toi, FiboAlgoBot) + 3 followers avec les 3 modes de risque différents,
ouverture d'un trade XAUUSD, vérification des lots calculés, clôture en profit, leaderboard
recalculé automatiquement (win rate 100%, P&L +0.62%). Tout fonctionne comme attendu.

## Ce qu'il reste à brancher côté toi

- **Authentification** : ces endpoints n'ont aucune sécurité pour l'instant — à protéger
  (API key, JWT, ou ce que tu utilises déjà dans saasdrevmbot) avant mise en prod, sinon
  n'importe qui pourrait déclencher des trades sur les comptes followers.
- **Compliance The5%ers** : si tes followers sont sur des comptes prop firm, vérifie que
  le copy-trading n'enfreint pas les règles anti-abus (comptes liés, gestion à distance)
  du programme High Stakes avant de l'activer en réel.
- **Frais/monétisation** (fonction Invo "earn from followers") : pas implémenté ici,
  dis-moi si tu veux que j'ajoute un système de commission par trade copié.
