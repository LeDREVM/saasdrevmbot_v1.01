"""
routes_copytrading_fastapi.py
--------------------------------
Router FastAPI équivalent, si saasdrevmbot tourne sur FastAPI plutôt que Flask.

Intégration :
    from routes_copytrading_fastapi import router as copytrading_router
    app.include_router(copytrading_router)
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from copy_trading import CopyTradingEngine

router = APIRouter(prefix="/api/copytrading", tags=["copy_trading"])
engine = CopyTradingEngine(db_path="data/copy_trading.db")


class TraderIn(BaseModel):
    name: str
    mt5_account_id: str = ""


class FollowIn(BaseModel):
    trader_id: str
    follower_account_id: str
    risk_mode: str = "mirror_ratio"
    risk_value: float = 1.0


class UnfollowIn(BaseModel):
    trader_id: str
    follower_account_id: str


class OpenTradeIn(BaseModel):
    trader_id: str
    symbol: str
    direction: str
    lot_size: float
    open_price: float
    sl: Optional[float] = None
    tp: Optional[float] = None
    trader_balance: Optional[float] = None
    follower_balances: Optional[dict[str, float]] = None


class CloseTradeIn(BaseModel):
    close_price: float


@router.post("/traders", status_code=201)
def create_trader(body: TraderIn):
    trader_id = engine.register_trader(body.name, body.mt5_account_id)
    return {"trader_id": trader_id}


@router.post("/follow", status_code=201)
def follow(body: FollowIn):
    follow_id = engine.follow_trader(
        trader_id=body.trader_id,
        follower_account_id=body.follower_account_id,
        risk_mode=body.risk_mode,
        risk_value=body.risk_value,
    )
    return {"follow_id": follow_id}


@router.post("/unfollow")
def unfollow(body: UnfollowIn):
    engine.unfollow_trader(body.trader_id, body.follower_account_id)
    return {"status": "ok"}


@router.get("/traders/{trader_id}/followers")
def followers(trader_id: str):
    return engine.get_followers(trader_id)


@router.post("/trades/open", status_code=201)
def open_trade(body: OpenTradeIn):
    return engine.open_trade(
        trader_id=body.trader_id,
        symbol=body.symbol,
        direction=body.direction,
        lot_size=body.lot_size,
        open_price=body.open_price,
        sl=body.sl,
        tp=body.tp,
        trader_balance=body.trader_balance,
        follower_balances=body.follower_balances,
    )


@router.post("/trades/{trade_id}/close")
def close_trade(trade_id: str, body: CloseTradeIn):
    try:
        return engine.close_trade(trade_id, body.close_price)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/orders/pending/{account_id}")
def pending_orders(account_id: str):
    return engine.get_pending_orders_for_account(account_id)


@router.post("/orders/{order_id}/sent")
def order_sent(order_id: str):
    engine.mark_order_sent(order_id)
    return {"status": "ok"}


@router.post("/orders/{order_id}/failed")
def order_failed(order_id: str):
    engine.mark_order_failed(order_id)
    return {"status": "ok"}


@router.get("/leaderboard")
def leaderboard(limit: int = 20):
    return engine.get_leaderboard(limit=limit)
