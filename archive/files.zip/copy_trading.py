"""
copy_trading.py
-----------------
Moteur de copy-trading autonome (façon Invo) pour saasdrevmbot.

Principe :
    1. Un "trader" (toi, ou un signal FiboAlgoBot) ouvre un trade -> open_trade()
    2. Le moteur calcule automatiquement la taille de lot pour chaque follower
       actif, selon son mode de risque (lot fixe, multiplicateur, % du solde).
    3. Les ordres à exécuter sont mis en file d'attente ("mirrored_orders").
    4. Ton bridge MT5 (Express.js, Kyrrahannon) vient régulièrement chercher
       les ordres "pending" via get_pending_orders_for_account() et les exécute,
       puis confirme avec mark_order_sent()/mark_order_failed().
    5. Quand le trade original se ferme -> close_trade() calcule le P&L
       et propage la clôture à tous les followers.
    6. get_leaderboard() calcule win rate / P&L% / nb followers par trader,
       comme le classement Invo.

Aucune dépendance externe -> compatible direct avec ton requirements.txt.
"""

from __future__ import annotations

import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional, Union, Literal

RiskMode = Literal["fixed_lot", "mirror_ratio", "pct_balance"]


@dataclass
class Trade:
    id: str
    trader_id: str
    symbol: str
    direction: str  # "buy" / "sell"
    lot_size: float
    open_price: float
    sl: Optional[float]
    tp: Optional[float]
    status: str  # "open" / "closed"
    opened_at: str
    close_price: Optional[float] = None
    closed_at: Optional[str] = None
    pnl_pct: Optional[float] = None


@dataclass
class MirroredOrder:
    id: str
    trade_id: str
    follower_account_id: str
    symbol: str
    direction: str
    lot_size: float
    status: str  # "pending" / "sent" / "failed" / "closed"
    created_at: str


class CopyTradingEngine:
    def __init__(self, db_path: Union[str, Path] = "copy_trading.db"):
        self.db_path = str(db_path)
        self._init_db()

    # ------------------------------------------------------------------ #
    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def _init_db(self) -> None:
        with self._conn() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS traders (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    mt5_account_id TEXT,
                    created_at TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS followers (
                    id TEXT PRIMARY KEY,
                    trader_id TEXT NOT NULL REFERENCES traders(id),
                    follower_account_id TEXT NOT NULL,
                    risk_mode TEXT NOT NULL,
                    risk_value REAL NOT NULL,
                    active INTEGER NOT NULL DEFAULT 1,
                    followed_at TEXT NOT NULL,
                    UNIQUE(trader_id, follower_account_id)
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS trades (
                    id TEXT PRIMARY KEY,
                    trader_id TEXT NOT NULL REFERENCES traders(id),
                    symbol TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    lot_size REAL NOT NULL,
                    open_price REAL NOT NULL,
                    sl REAL,
                    tp REAL,
                    status TEXT NOT NULL,
                    opened_at TEXT NOT NULL,
                    close_price REAL,
                    closed_at TEXT,
                    pnl_pct REAL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS mirrored_orders (
                    id TEXT PRIMARY KEY,
                    trade_id TEXT NOT NULL REFERENCES trades(id),
                    follower_account_id TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    lot_size REAL NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
                """
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_trades_trader ON trades(trader_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_orders_follower ON mirrored_orders(follower_account_id, status)")

    # ------------------------------------------------------------------ #
    # Gestion traders / followers
    # ------------------------------------------------------------------ #
    def register_trader(self, name: str, mt5_account_id: str = "") -> str:
        trader_id = str(uuid.uuid4())
        with self._conn() as conn:
            conn.execute(
                "INSERT INTO traders (id, name, mt5_account_id, created_at) VALUES (?, ?, ?, ?)",
                (trader_id, name, mt5_account_id, datetime.utcnow().isoformat()),
            )
        return trader_id

    def follow_trader(
        self,
        trader_id: str,
        follower_account_id: str,
        risk_mode: RiskMode = "mirror_ratio",
        risk_value: float = 1.0,
    ) -> str:
        """
        risk_mode :
            - "fixed_lot"    -> risk_value = lot fixe à chaque trade copié
            - "mirror_ratio" -> risk_value = multiplicateur du lot du trader (1.0 = identique)
            - "pct_balance"  -> risk_value = % du solde du follower à risquer (nécessite balance
                                 fournie à l'ouverture du trade via open_trade(follower_balances=...))
        """
        follow_id = str(uuid.uuid4())
        with self._conn() as conn:
            conn.execute(
                """
                INSERT INTO followers (id, trader_id, follower_account_id, risk_mode, risk_value, active, followed_at)
                VALUES (?, ?, ?, ?, ?, 1, ?)
                ON CONFLICT(trader_id, follower_account_id) DO UPDATE SET
                    risk_mode=excluded.risk_mode, risk_value=excluded.risk_value, active=1
                """,
                (follow_id, trader_id, follower_account_id, risk_mode, risk_value, datetime.utcnow().isoformat()),
            )
        return follow_id

    def unfollow_trader(self, trader_id: str, follower_account_id: str) -> None:
        with self._conn() as conn:
            conn.execute(
                "UPDATE followers SET active=0 WHERE trader_id=? AND follower_account_id=?",
                (trader_id, follower_account_id),
            )

    def get_followers(self, trader_id: str, active_only: bool = True) -> list[dict]:
        query = "SELECT id, follower_account_id, risk_mode, risk_value, active FROM followers WHERE trader_id=?"
        if active_only:
            query += " AND active=1"
        with self._conn() as conn:
            rows = conn.execute(query, (trader_id,)).fetchall()
        return [
            {"id": r[0], "follower_account_id": r[1], "risk_mode": r[2], "risk_value": r[3], "active": bool(r[4])}
            for r in rows
        ]

    # ------------------------------------------------------------------ #
    # Calcul de la taille de lot pour un follower
    # ------------------------------------------------------------------ #
    @staticmethod
    def _calculate_follower_lot(
        trader_lot: float,
        risk_mode: str,
        risk_value: float,
        follower_balance: Optional[float] = None,
        trader_balance: Optional[float] = None,
    ) -> float:
        if risk_mode == "fixed_lot":
            lot = risk_value
        elif risk_mode == "mirror_ratio":
            lot = trader_lot * risk_value
        elif risk_mode == "pct_balance":
            if follower_balance is None:
                # fallback : identique au trader si pas de solde fourni
                lot = trader_lot
            elif trader_balance:
                # on garde la même proportion lot/solde que le trader
                lot = trader_lot * (follower_balance / trader_balance) * risk_value
            else:
                lot = trader_lot * risk_value
        else:
            lot = trader_lot
        return round(max(lot, 0.01), 2)  # 0.01 = lot minimum standard MT5

    # ------------------------------------------------------------------ #
    # Ouverture / clôture de trade (déclenche la réplication)
    # ------------------------------------------------------------------ #
    def open_trade(
        self,
        trader_id: str,
        symbol: str,
        direction: str,
        lot_size: float,
        open_price: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        trader_balance: Optional[float] = None,
        follower_balances: Optional[dict[str, float]] = None,
    ) -> dict:
        """
        Ouvre un trade côté trader et génère automatiquement les ordres
        à répliquer pour tous les followers actifs.

        follower_balances : {follower_account_id: balance} -> utile pour risk_mode="pct_balance"
        Retourne le trade + la liste des ordres à envoyer au bridge MT5.
        """
        trade_id = str(uuid.uuid4())
        now = datetime.utcnow().isoformat()
        follower_balances = follower_balances or {}

        with self._conn() as conn:
            conn.execute(
                """
                INSERT INTO trades (id, trader_id, symbol, direction, lot_size, open_price, sl, tp, status, opened_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open', ?)
                """,
                (trade_id, trader_id, symbol, direction, lot_size, open_price, sl, tp, now),
            )

        orders = []
        for f in self.get_followers(trader_id, active_only=True):
            follower_lot = self._calculate_follower_lot(
                trader_lot=lot_size,
                risk_mode=f["risk_mode"],
                risk_value=f["risk_value"],
                follower_balance=follower_balances.get(f["follower_account_id"]),
                trader_balance=trader_balance,
            )
            order_id = str(uuid.uuid4())
            with self._conn() as conn:
                conn.execute(
                    """
                    INSERT INTO mirrored_orders (id, trade_id, follower_account_id, symbol, direction, lot_size, status, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)
                    """,
                    (order_id, trade_id, f["follower_account_id"], symbol, direction, follower_lot, now),
                )
            orders.append(
                {
                    "order_id": order_id,
                    "follower_account_id": f["follower_account_id"],
                    "symbol": symbol,
                    "direction": direction,
                    "lot_size": follower_lot,
                }
            )

        return {"trade_id": trade_id, "mirrored_orders": orders}

    def close_trade(self, trade_id: str, close_price: float) -> dict:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT trader_id, symbol, direction, lot_size, open_price FROM trades WHERE id=?",
                (trade_id,),
            ).fetchone()
            if row is None:
                raise ValueError(f"Trade introuvable : {trade_id}")

            _, symbol, direction, lot_size, open_price = row
            pnl_pct = self._pnl_pct(direction, open_price, close_price)
            now = datetime.utcnow().isoformat()

            conn.execute(
                "UPDATE trades SET status='closed', close_price=?, closed_at=?, pnl_pct=? WHERE id=?",
                (close_price, now, pnl_pct, trade_id),
            )
            conn.execute(
                "UPDATE mirrored_orders SET status='closed' WHERE trade_id=? AND status IN ('pending','sent')",
                (trade_id,),
            )

        return {"trade_id": trade_id, "close_price": close_price, "pnl_pct": pnl_pct}

    @staticmethod
    def _pnl_pct(direction: str, open_price: float, close_price: float) -> float:
        if open_price == 0:
            return 0.0
        raw = (close_price - open_price) / open_price
        if direction.lower() == "sell":
            raw = -raw
        return round(raw * 100, 4)

    # ------------------------------------------------------------------ #
    # File d'attente pour le bridge MT5 (polling côté Express.js/EA)
    # ------------------------------------------------------------------ #
    def get_pending_orders_for_account(self, follower_account_id: str) -> list[dict]:
        with self._conn() as conn:
            rows = conn.execute(
                """
                SELECT id, trade_id, symbol, direction, lot_size, created_at
                FROM mirrored_orders
                WHERE follower_account_id=? AND status='pending'
                ORDER BY created_at ASC
                """,
                (follower_account_id,),
            ).fetchall()
        return [
            {"order_id": r[0], "trade_id": r[1], "symbol": r[2], "direction": r[3], "lot_size": r[4], "created_at": r[5]}
            for r in rows
        ]

    def mark_order_sent(self, order_id: str) -> None:
        with self._conn() as conn:
            conn.execute("UPDATE mirrored_orders SET status='sent' WHERE id=?", (order_id,))

    def mark_order_failed(self, order_id: str) -> None:
        with self._conn() as conn:
            conn.execute("UPDATE mirrored_orders SET status='failed' WHERE id=?", (order_id,))

    # ------------------------------------------------------------------ #
    # Leaderboard façon Invo
    # ------------------------------------------------------------------ #
    def get_leaderboard(self, limit: int = 20) -> list[dict]:
        with self._conn() as conn:
            traders = conn.execute("SELECT id, name FROM traders").fetchall()
            board = []
            for trader_id, name in traders:
                trades = conn.execute(
                    "SELECT pnl_pct FROM trades WHERE trader_id=? AND status='closed'",
                    (trader_id,),
                ).fetchall()
                pnl_values = [t[0] for t in trades if t[0] is not None]
                nb_trades = len(pnl_values)
                nb_wins = sum(1 for p in pnl_values if p > 0)
                win_rate = round((nb_wins / nb_trades) * 100, 1) if nb_trades else 0.0
                total_pnl_pct = round(sum(pnl_values), 2)
                nb_followers = conn.execute(
                    "SELECT COUNT(*) FROM followers WHERE trader_id=? AND active=1", (trader_id,)
                ).fetchone()[0]

                board.append(
                    {
                        "trader_id": trader_id,
                        "name": name,
                        "nb_trades": nb_trades,
                        "win_rate": win_rate,
                        "total_pnl_pct": total_pnl_pct,
                        "nb_followers": nb_followers,
                    }
                )

        board.sort(key=lambda x: x["total_pnl_pct"], reverse=True)
        return board[:limit]
